﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        decimal toplamTutar = 0;
        List<object> siparisim = new List<object>();
        private void Form1_Load(object sender, EventArgs e)
        {
            List<ebat> ebatlar = new List<ebat>();
            ebat _ebatlar;

            _ebatlar = new ebat();
            _ebatlar.Ebatlar = "Küçük";
            _ebatlar.EbatCarpanlari = 1;
            ebatlar.Add(_ebatlar);

            _ebatlar = new ebat();
            _ebatlar.Ebatlar = "Orta";
            _ebatlar.EbatCarpanlari = 1.25M;
            ebatlar.Add(_ebatlar);

            _ebatlar = new ebat();
            _ebatlar.Ebatlar = "Büyük";
            _ebatlar.EbatCarpanlari = 1.75M;
            ebatlar.Add(_ebatlar);

            _ebatlar = new ebat();
            _ebatlar.Ebatlar = "Maksi";
            _ebatlar.EbatCarpanlari = 2M;
            ebatlar.Add(_ebatlar);

            foreach (ebat item in ebatlar)
            {
                cbxEbatlar.Items.Add(item);
            }

            List<pizzalar> listPizzalar = new List<pizzalar>();
            pizzalar pizza;

            pizza = new pizzalar();
            pizza.Pizzalar = "KLASİK";
            pizza.Fiyat = 14M;
            listPizzalar.Add(pizza);

            pizza = new pizzalar();
            pizza.Pizzalar = "KARIŞIK";
            pizza.Fiyat = 17M;
            listPizzalar.Add(pizza);

            pizza = new pizzalar();
            pizza.Pizzalar = "EXTRAVAGANZA";
            pizza.Fiyat = 21M;
            listPizzalar.Add(pizza);

            pizza = new pizzalar();
            pizza.Pizzalar = "ITALIANO";
            pizza.Fiyat = 20M;
            listPizzalar.Add(pizza);

            pizza = new pizzalar();
            pizza.Pizzalar = "TURKISH";
            pizza.Fiyat = 23M;
            listPizzalar.Add(pizza);

            pizza = new pizzalar();
            pizza.Pizzalar = "TUNA";
            pizza.Fiyat = 18M;
            listPizzalar.Add(pizza);

            pizza = new pizzalar();
            pizza.Pizzalar = "SEAFEED";
            pizza.Fiyat = 19M;
            listPizzalar.Add(pizza);

            pizza = new pizzalar();
            pizza.Pizzalar = "KASTAMONU";
            pizza.Fiyat = 20M;
            listPizzalar.Add(pizza);

            pizza = new pizzalar();
            pizza.Pizzalar = "CALYPSO";
            pizza.Fiyat = 24M;
            listPizzalar.Add(pizza);

            pizza = new pizzalar();
            pizza.Pizzalar = "AKDENİZ";
            pizza.Fiyat = 21M;
            listPizzalar.Add(pizza);

            pizza = new pizzalar();
            pizza.Pizzalar = "KARADENİZ";
            pizza.Fiyat = 21M;
            listPizzalar.Add(pizza);

            foreach (pizzalar item in listPizzalar)
            {
                lboxPizzalar.Items.Add(item);
            }

            List<Malzemeler> malzemeliste = new List<Malzemeler>();

            malzemeliste.Add(new Malzemeler
            {
                MalzemeAdi = "Dana Jambon"
            });

            malzemeliste.Add(new Malzemeler
            {
                MalzemeAdi = "Sosis"
            });
            malzemeliste.Add(new Malzemeler
            {
                MalzemeAdi = "Mısır"
            });
            malzemeliste.Add(new Malzemeler
            {
                MalzemeAdi = "Ancuez"
            });
            malzemeliste.Add(new Malzemeler
            {
                MalzemeAdi = "Zeytin"
            });
            malzemeliste.Add(new Malzemeler
            {
                MalzemeAdi = "Salam"
            });
            malzemeliste.Add(new Malzemeler
            {
                MalzemeAdi = "Sucuk"
            });
            malzemeliste.Add(new Malzemeler
            {
                MalzemeAdi = "Mantar"
            });
            malzemeliste.Add(new Malzemeler
            {
                MalzemeAdi = "Ton Balığı"
            });
            malzemeliste.Add(new Malzemeler
            {
                MalzemeAdi = "Peynir"
            });

            foreach (Malzemeler item in malzemeliste)
            {
                cboxlistMalzemeler.Items.Add(item.MalzemeAdi);
            }
        }

        private void btHesapla_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtAdet.Text == "")
                    MessageBox.Show("Lütfen Adet Birimini Doldurunuz", "Hata..", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                else if (lboxPizzalar.SelectedItems.Count == 0 || cbxEbatlar.SelectedIndex < 0)
                    MessageBox.Show("Lütfen Ebatı ve Pizzayı Seçiniz", "Hata..", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                else
                {
                    pizzalar pizza = lboxPizzalar.SelectedItem as pizzalar;
                    ebat ebatlar = cbxEbatlar.SelectedItem as ebat;

                    decimal topla = (pizza.Fiyat * ebatlar.EbatCarpanlari) * decimal.Parse(txtAdet.Text);
                    txtTutar.Text = topla.ToString("#,#.00#");
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Lütfen Adeti Doğru Şekilde Yazınız", "Hata...", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSepeteEkle_Click(object sender, EventArgs e)
        {
            if (txtAdet.Text == "")
                MessageBox.Show("Lütfen Adet Birimini Doldurunuz", "Hata..", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            else if (lboxPizzalar.SelectedItems.Count == 0 || cbxEbatlar.SelectedIndex < 0)
                MessageBox.Show("Lütfen Ebatı ve Pizzayı Seçiniz", "Hata..", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            else if (rdinceKenar.Checked == false && rdKalinKenar.Checked == false)
                MessageBox.Show("Lütfen Hamur Kenarı Seçiniz", "Hata..", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            else if (cboxlistMalzemeler.CheckedItems.Count == 0)
                MessageBox.Show("Lütfen Enaz Bir tane Malzeme Seçiniz", "Hata..", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            else
            {
                siparisler siparis = new siparisler();
                siparis.ebatlar = cbxEbatlar.SelectedItem as ebat;
                siparis.pizza = lboxPizzalar.SelectedItem as pizzalar;
                siparis.adet = int.Parse(txtAdet.Text);

                if (rdinceKenar.Checked)
                    siparis.Kenar = "İnce Kenar";
                else if (rdKalinKenar.Checked)
                    siparis.Kenar = "Kalın Kenar";

                foreach (object item in cboxlistMalzemeler.CheckedItems)
                {
                    siparis.Malzemeler += item.ToString();
                }
                toplamTutar += siparis.toplamTutar;
                lboxSiparisler.Items.Add(siparis);
                lblToplamTutar.Text = toplamTutar.ToString("#,#.00#") + " TL";
                temizle();
            }
        }

        private void temizle()
        {
            txtAdet.ResetText();
            txtTutar.ResetText();
            cbxEbatlar.SelectedIndex = -1;
            lboxPizzalar.SelectedIndex = -1;
            rdinceKenar.Checked = false;
            rdKalinKenar.Checked = false;

            for (int i = 0; i < cboxlistMalzemeler.Items.Count; i++)
            {
                cboxlistMalzemeler.SetItemCheckState(i, CheckState.Unchecked);
            }
            cboxlistMalzemeler.SelectedIndex = -1;
        }

        private void btnSiparisiOnayla_Click(object sender, EventArgs e)
        {
            foreach (siparisler item in lboxSiparisler.Items)
            {
                siparisim.Add((siparisler)item);
            }
            string mesaj = string.Format("Toplam : {0} adet siparisiniz. \n{1} TL Tutarındadır.", siparisim.Count(), toplamTutar.ToString("#,#.00#"));
            MessageBox.Show(mesaj, "Siparisler Onaylandı", MessageBoxButtons.OK, MessageBoxIcon.Information);
            toplamTutar = 0;
            lblToplamTutar.Text = "________TL";
            lboxSiparisler.Items.Clear();
        }

    }
}
