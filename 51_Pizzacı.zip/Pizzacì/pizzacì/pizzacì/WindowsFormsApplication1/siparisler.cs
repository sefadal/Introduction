﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
    class siparisler
    {
        public pizzalar pizza { get; set; }
        public ebat ebatlar { get; set; }
        public string Kenar { get; set; }
        public decimal birimFiyati
        {
            get
            {
                return pizza.Fiyat * ebatlar.EbatCarpanlari;
            }
        }
        public decimal toplamTutar
        {
            get
            {
                return adet * birimFiyati;
            }            
        }
        public string Malzemeler { get; set; }
        public int adet { get; set; }
        public decimal tutar { get; set; }

        public override string ToString()
        {
            string donus;

            donus = ebatlar.ToString() + ", ";
            donus += pizza.ToString() + ", ";
            donus += Kenar + ", ";
            donus += Malzemeler.TrimEnd(Convert.ToChar(",")) + " ; ";
            donus += adet.ToString() + " x ";
            donus += birimFiyati.ToString("#,#.00#");
            donus += " = " + toplamTutar.ToString("#,#.00#");
            return donus;
        }
    }
}
