﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cbxEbatlar = new System.Windows.Forms.ComboBox();
            this.lboxPizzalar = new System.Windows.Forms.ListBox();
            this.rdinceKenar = new System.Windows.Forms.RadioButton();
            this.rdKalinKenar = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cboxlistMalzemeler = new System.Windows.Forms.CheckedListBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtAdet = new System.Windows.Forms.TextBox();
            this.btHesapla = new System.Windows.Forms.Button();
            this.txtTutar = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btnSepeteEkle = new System.Windows.Forms.Button();
            this.btnSiparisiOnayla = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.lblToplamTutar = new System.Windows.Forms.Label();
            this.lboxSiparisler = new System.Windows.Forms.ListBox();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(703, 69);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.Snow;
            this.label1.Location = new System.Drawing.Point(220, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(275, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "Pizzacı Sipariş Ekranı";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(25, 83);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Ebatlar :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(25, 110);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Pizzalar :";
            // 
            // cbxEbatlar
            // 
            this.cbxEbatlar.FormattingEnabled = true;
            this.cbxEbatlar.Location = new System.Drawing.Point(77, 80);
            this.cbxEbatlar.Name = "cbxEbatlar";
            this.cbxEbatlar.Size = new System.Drawing.Size(193, 21);
            this.cbxEbatlar.TabIndex = 3;
            // 
            // lboxPizzalar
            // 
            this.lboxPizzalar.FormattingEnabled = true;
            this.lboxPizzalar.Location = new System.Drawing.Point(77, 107);
            this.lboxPizzalar.Name = "lboxPizzalar";
            this.lboxPizzalar.Size = new System.Drawing.Size(193, 134);
            this.lboxPizzalar.TabIndex = 4;
            // 
            // rdinceKenar
            // 
            this.rdinceKenar.AutoSize = true;
            this.rdinceKenar.Location = new System.Drawing.Point(77, 247);
            this.rdinceKenar.Name = "rdinceKenar";
            this.rdinceKenar.Size = new System.Drawing.Size(77, 17);
            this.rdinceKenar.TabIndex = 5;
            this.rdinceKenar.TabStop = true;
            this.rdinceKenar.Text = "İnce Kenar";
            this.rdinceKenar.UseVisualStyleBackColor = true;
            // 
            // rdKalinKenar
            // 
            this.rdKalinKenar.AutoSize = true;
            this.rdKalinKenar.Location = new System.Drawing.Point(181, 247);
            this.rdKalinKenar.Name = "rdKalinKenar";
            this.rdKalinKenar.Size = new System.Drawing.Size(79, 17);
            this.rdKalinKenar.TabIndex = 6;
            this.rdKalinKenar.TabStop = true;
            this.rdKalinKenar.Text = "Kalın Kenar";
            this.rdKalinKenar.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cboxlistMalzemeler);
            this.groupBox1.Location = new System.Drawing.Point(78, 277);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(192, 140);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Malzemeler";
            // 
            // cboxlistMalzemeler
            // 
            this.cboxlistMalzemeler.BackColor = System.Drawing.SystemColors.Control;
            this.cboxlistMalzemeler.CheckOnClick = true;
            this.cboxlistMalzemeler.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cboxlistMalzemeler.FormattingEnabled = true;
            this.cboxlistMalzemeler.HorizontalExtent = 1;
            this.cboxlistMalzemeler.Location = new System.Drawing.Point(3, 16);
            this.cboxlistMalzemeler.MultiColumn = true;
            this.cboxlistMalzemeler.Name = "cboxlistMalzemeler";
            this.cboxlistMalzemeler.Size = new System.Drawing.Size(186, 121);
            this.cboxlistMalzemeler.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(25, 431);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Adet :";
            // 
            // txtAdet
            // 
            this.txtAdet.Location = new System.Drawing.Point(77, 427);
            this.txtAdet.Name = "txtAdet";
            this.txtAdet.Size = new System.Drawing.Size(37, 20);
            this.txtAdet.TabIndex = 9;
            // 
            // btHesapla
            // 
            this.btHesapla.Location = new System.Drawing.Point(120, 425);
            this.btHesapla.Name = "btHesapla";
            this.btHesapla.Size = new System.Drawing.Size(63, 23);
            this.btHesapla.TabIndex = 10;
            this.btHesapla.Text = "Hesapla";
            this.btHesapla.UseVisualStyleBackColor = true;
            this.btHesapla.Click += new System.EventHandler(this.btHesapla_Click);
            // 
            // txtTutar
            // 
            this.txtTutar.Location = new System.Drawing.Point(223, 425);
            this.txtTutar.Name = "txtTutar";
            this.txtTutar.Size = new System.Drawing.Size(47, 20);
            this.txtTutar.TabIndex = 12;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(187, 429);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(38, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Tutar :";
            // 
            // btnSepeteEkle
            // 
            this.btnSepeteEkle.Location = new System.Drawing.Point(276, 421);
            this.btnSepeteEkle.Name = "btnSepeteEkle";
            this.btnSepeteEkle.Size = new System.Drawing.Size(113, 23);
            this.btnSepeteEkle.TabIndex = 13;
            this.btnSepeteEkle.Text = "Sepete Ekle";
            this.btnSepeteEkle.UseVisualStyleBackColor = true;
            this.btnSepeteEkle.Click += new System.EventHandler(this.btnSepeteEkle_Click);
            // 
            // btnSiparisiOnayla
            // 
            this.btnSiparisiOnayla.Location = new System.Drawing.Point(522, 419);
            this.btnSiparisiOnayla.Name = "btnSiparisiOnayla";
            this.btnSiparisiOnayla.Size = new System.Drawing.Size(152, 23);
            this.btnSiparisiOnayla.TabIndex = 14;
            this.btnSiparisiOnayla.Text = "Siparişi Onayla";
            this.btnSiparisiOnayla.UseVisualStyleBackColor = true;
            this.btnSiparisiOnayla.Click += new System.EventHandler(this.btnSiparisiOnayla_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(469, 387);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(76, 13);
            this.label6.TabIndex = 15;
            this.label6.Text = "Toplam Tutar :";
            // 
            // lblToplamTutar
            // 
            this.lblToplamTutar.AutoSize = true;
            this.lblToplamTutar.Location = new System.Drawing.Point(572, 387);
            this.lblToplamTutar.Name = "lblToplamTutar";
            this.lblToplamTutar.Size = new System.Drawing.Size(92, 13);
            this.lblToplamTutar.TabIndex = 16;
            this.lblToplamTutar.Text = "___________ .TL";
            // 
            // lboxSiparisler
            // 
            this.lboxSiparisler.FormattingEnabled = true;
            this.lboxSiparisler.Location = new System.Drawing.Point(274, 81);
            this.lboxSiparisler.Name = "lboxSiparisler";
            this.lboxSiparisler.Size = new System.Drawing.Size(400, 290);
            this.lboxSiparisler.TabIndex = 17;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(703, 488);
            this.Controls.Add(this.lboxSiparisler);
            this.Controls.Add(this.lblToplamTutar);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.btnSiparisiOnayla);
            this.Controls.Add(this.btnSepeteEkle);
            this.Controls.Add(this.txtTutar);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btHesapla);
            this.Controls.Add(this.txtAdet);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.rdKalinKenar);
            this.Controls.Add(this.rdinceKenar);
            this.Controls.Add(this.lboxPizzalar);
            this.Controls.Add(this.cbxEbatlar);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "                                                                                 " +
    "                Pizzacım  V.1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbxEbatlar;
        private System.Windows.Forms.ListBox lboxPizzalar;
        private System.Windows.Forms.RadioButton rdinceKenar;
        private System.Windows.Forms.RadioButton rdKalinKenar;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtAdet;
        private System.Windows.Forms.Button btHesapla;
        private System.Windows.Forms.TextBox txtTutar;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnSepeteEkle;
        private System.Windows.Forms.Button btnSiparisiOnayla;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblToplamTutar;
        private System.Windows.Forms.ListBox lboxSiparisler;
        private System.Windows.Forms.CheckedListBox cboxlistMalzemeler;
    }
}

