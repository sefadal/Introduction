﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form8 : Form
    {
        Thread cevirici = new Thread(cevir);

        public Form8()
        {
            InitializeComponent();
        }

        private void btnCevir_Click(object sender, EventArgs e)
        {
            dongu = 0;
            tmrCevirici.Interval = 100;
            tmrCevirici.Start();
            sayilar = new int[6];
        }
        public int say;
        static void cevir()
        {
            //  this.Text = "";
            //  txtS1.Text = "0";
            //say++;
        }
        int dongu = 0;
        int[] sayilar = new int[6];
        private void tmrCevirici_Tick(object sender, EventArgs e)
        {
            tmrCevirici.Stop();
            Random rasgele = new Random();
            int[] say = new int[6];

            say[0] = rasgele.Next(1, 49);
            say[1] = rasgele.Next(1, 49);
            say[2] = rasgele.Next(1, 49);
            say[3] = rasgele.Next(1, 49);
            say[4] = rasgele.Next(1, 49);
            say[5] = rasgele.Next(1, 49);

            txtS1.Text = say[0].ToString("0#");
            txtS2.Text = say[1].ToString("0#");
            txtS3.Text = say[2].ToString("0#");
            txtS4.Text = say[2].ToString("0#");
            txtS5.Text = say[4].ToString("0#");
            txtS6.Text = say[5].ToString("0#");

            dongu++;
            tmrCevirici.Start();
            if (dongu >= 10)
                tmrCevirici.Stop();
            {
             
                for (int i = 0; i < 6; i++) // Aynı sayıdan birden fazla varsa hata verecek.
                {

                    if (Array.IndexOf(sayilar, say[i]) == -1)
                        sayilar[i] = say[i];
                    else
                    {
                        say[i] = rasgele.Next(1, 49);
                        i--;
                    }
                }
                // Eşleşen Sayılar Düzeltildi Şimdi Tekrar Giriyoruz
                txtS1.Text = sayilar[0].ToString("0#");
                txtS2.Text = sayilar[1].ToString("0#");
                txtS3.Text = sayilar[2].ToString("0#");
                txtS4.Text = sayilar[3].ToString("0#");
                txtS5.Text = sayilar[4].ToString("0#");
                txtS6.Text = sayilar[5].ToString("0#");
            }
        }

    }
}
