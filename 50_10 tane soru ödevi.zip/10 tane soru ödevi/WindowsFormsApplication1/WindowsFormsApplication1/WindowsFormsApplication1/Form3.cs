﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void btnAsal_Click(object sender, EventArgs e)
        {


            int sayi = int.Parse(txtAsal.Text);


            bool asalmi = false;
            for (int i = 2; i < sayi; i++)
            {
                if (sayi % i == 0)
                {
                    MessageBox.Show("Asal Değil");
                    asalmi = true;
                    return;
                }                
            }

            if (asalmi == false) MessageBox.Show("Asal");
        }
    }
}
