﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e)
        {

        }
        string birler;
        string onlar;
        string yuzler;
        string binler;
        string rakam;
        private void button1_Click(object sender, EventArgs e)
        {
            int say = int.Parse(txtSayi.Text);          
            int uzunluk = say.ToString().Length;
            birler = "";
            onlar = "";
            yuzler = "";
            binler = "";
            rakam = "";
            for (int i = 0; i < uzunluk; i++)
            {
                char sayi = Convert.ToChar(say.ToString().Substring((uzunluk - 1) - i, 1));

                if (sayi == '1')  // Birler 
                    rakam = "bir";
                else if (sayi == '2')
                    rakam = "iki";
                else if (sayi == '3')
                    rakam = "üç";
                else if (sayi == '4')
                    rakam = "dört";
                else if (sayi == '5')
                    rakam = "beş";
                else if (sayi == '6')
                    rakam = "altı";
                else if (sayi == '7')
                    rakam = "yedi";
                else if (sayi == '8')
                    rakam = "sekiz";
                else if (sayi == '9')
                    rakam = "dokuz";
                else if (sayi == '0')
                    rakam = "";



                if (i == 0)
                    birler = rakam;
                else if (i == 1) // Onlar 
                {
                    if (sayi == '1')
                        onlar = "on";
                    else if (sayi == '2')
                        onlar = "yirmi";
                    else if (sayi == '3')
                        onlar = "otuz";
                    else if (sayi == '4')
                        onlar = "kırk";
                    else if (sayi == '5')
                        onlar = "elli";
                    else if (sayi == '6')
                        onlar = "altmış";
                    else if (sayi == '7')
                        onlar = "yetmiş";
                    else if (sayi == '8')
                        onlar = "seksen";
                    else if (sayi == '9')
                        onlar = "doksan";
                    else if (sayi == '0')
                        onlar = "";
                }
                else if (i == 2) // yuzler
                    if (sayi == '1')
                        yuzler = "yüz";
                    else if (sayi == '0')
                        yuzler = "";
                    else
                        yuzler = rakam + "yüz";
                else if (i == 3) // binler
                {
                    if (sayi == '1')
                        binler = "bin";
                    else binler = rakam + "bin";
                }
            }

            lblYazi.Text = binler + " " + yuzler + " " + onlar + " " + birler;

        }
    }
}
