﻿namespace WindowsFormsApplication1
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtAsal = new System.Windows.Forms.TextBox();
            this.btnAsal = new System.Windows.Forms.Button();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.SuspendLayout();
            // 
            // txtAsal
            // 
            this.txtAsal.Location = new System.Drawing.Point(25, 27);
            this.txtAsal.Name = "txtAsal";
            this.txtAsal.Size = new System.Drawing.Size(100, 20);
            this.txtAsal.TabIndex = 0;
            // 
            // btnAsal
            // 
            this.btnAsal.Location = new System.Drawing.Point(25, 53);
            this.btnAsal.Name = "btnAsal";
            this.btnAsal.Size = new System.Drawing.Size(100, 23);
            this.btnAsal.TabIndex = 1;
            this.btnAsal.Text = "ASAL MI?";
            this.btnAsal.UseVisualStyleBackColor = true;
            this.btnAsal.Click += new System.EventHandler(this.btnAsal_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(542, 302);
            this.Controls.Add(this.btnAsal);
            this.Controls.Add(this.txtAsal);
            this.Name = "Form3";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtAsal;
        private System.Windows.Forms.Button btnAsal;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
    }
}