﻿namespace WindowsFormsApplication1
{
    partial class Form8
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtS1 = new System.Windows.Forms.TextBox();
            this.txtS2 = new System.Windows.Forms.TextBox();
            this.txtS3 = new System.Windows.Forms.TextBox();
            this.txtS4 = new System.Windows.Forms.TextBox();
            this.txtS5 = new System.Windows.Forms.TextBox();
            this.txtS6 = new System.Windows.Forms.TextBox();
            this.btnCevir = new System.Windows.Forms.Button();
            this.tmrCevirici = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // txtS1
            // 
            this.txtS1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtS1.Location = new System.Drawing.Point(39, 50);
            this.txtS1.Multiline = true;
            this.txtS1.Name = "txtS1";
            this.txtS1.Size = new System.Drawing.Size(32, 30);
            this.txtS1.TabIndex = 0;
            this.txtS1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtS2
            // 
            this.txtS2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtS2.Location = new System.Drawing.Point(77, 50);
            this.txtS2.Multiline = true;
            this.txtS2.Name = "txtS2";
            this.txtS2.Size = new System.Drawing.Size(32, 30);
            this.txtS2.TabIndex = 1;
            this.txtS2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtS3
            // 
            this.txtS3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtS3.Location = new System.Drawing.Point(115, 50);
            this.txtS3.Multiline = true;
            this.txtS3.Name = "txtS3";
            this.txtS3.Size = new System.Drawing.Size(32, 30);
            this.txtS3.TabIndex = 2;
            this.txtS3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtS4
            // 
            this.txtS4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtS4.Location = new System.Drawing.Point(153, 50);
            this.txtS4.Multiline = true;
            this.txtS4.Name = "txtS4";
            this.txtS4.Size = new System.Drawing.Size(32, 30);
            this.txtS4.TabIndex = 3;
            this.txtS4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtS5
            // 
            this.txtS5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtS5.Location = new System.Drawing.Point(191, 50);
            this.txtS5.Multiline = true;
            this.txtS5.Name = "txtS5";
            this.txtS5.Size = new System.Drawing.Size(32, 30);
            this.txtS5.TabIndex = 4;
            this.txtS5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtS6
            // 
            this.txtS6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtS6.Location = new System.Drawing.Point(229, 50);
            this.txtS6.Multiline = true;
            this.txtS6.Name = "txtS6";
            this.txtS6.Size = new System.Drawing.Size(32, 30);
            this.txtS6.TabIndex = 5;
            this.txtS6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnCevir
            // 
            this.btnCevir.Location = new System.Drawing.Point(89, 108);
            this.btnCevir.Name = "btnCevir";
            this.btnCevir.Size = new System.Drawing.Size(75, 23);
            this.btnCevir.TabIndex = 6;
            this.btnCevir.Text = "ÇEVİR";
            this.btnCevir.UseVisualStyleBackColor = true;
            this.btnCevir.Click += new System.EventHandler(this.btnCevir_Click);
            // 
            // tmrCevirici
            // 
            this.tmrCevirici.Tick += new System.EventHandler(this.tmrCevirici_Tick);
            // 
            // Form8
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(497, 206);
            this.Controls.Add(this.btnCevir);
            this.Controls.Add(this.txtS6);
            this.Controls.Add(this.txtS5);
            this.Controls.Add(this.txtS4);
            this.Controls.Add(this.txtS3);
            this.Controls.Add(this.txtS2);
            this.Controls.Add(this.txtS1);
            this.Name = "Form8";
            this.Text = "Form8";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCevir;
        public System.Windows.Forms.TextBox txtS1;
        public System.Windows.Forms.TextBox txtS2;
        public System.Windows.Forms.TextBox txtS3;
        public System.Windows.Forms.TextBox txtS4;
        public System.Windows.Forms.TextBox txtS5;
        public System.Windows.Forms.TextBox txtS6;
        private System.Windows.Forms.Timer tmrCevirici;
    }
}