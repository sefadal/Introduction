﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form10 : Form
    {
        public Form10()
        {
            InitializeComponent();
        }

        List<int> sayilar = new List<int>();

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (sayilar.Count < 10)
                {
                    sayilar.Add(int.Parse(txtSayi.Text));
                }
                else MessageBox.Show("Toplam 10 Adet SAyı Ekleyebilirsiniz!", "Hata..", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            catch (Exception)
            {

                MessageBox.Show("Lütfen Normal Bir Sayı Giriniz.", "Hata..", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                txtSayi.ResetText();
                txtSayi.Focus();
            }
        }
        private void button1_Click_1(object sender, EventArgs e)
        {
            if (sayilar.Count <= 0)
                MessageBox.Show("Lütfen Önce Sayı Ekleyiniz.", "Hata..", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            else
            {
                Label lbl;
                int sira = 0;
                int up = 10;
                int ortalama = sayilar.Sum() / sayilar.Count();
                int yakin = 0;
                bool ilk = true;
                foreach (int item in sayilar)
                {
                    lbl = new Label
                    {
                        Text = item.ToString(),
                        Name = "lbl" + sira.ToString(),
                        Size = new System.Drawing.Size(250, 15),
                        Location = new Point(txtSayi.Location.X + 100, up)
                    };
                    this.Controls.Add(lbl);
                    sira++;
                    up += 20;


                    if (ilk) // Eğer ilk true ise aşşağıdaki kodlar çalışmaz
                    {
                        ilk = false;
                        yakin = item;
                    }
                    else
                    {
                        int sayi = Math.Abs(item - ortalama);
                        int _yakin = Math.Abs(yakin - ortalama);

                        if (_yakin > sayi)
                        {
                            yakin = item;
                        }
                    }
                }

                lblEnKucuk.Text = sayilar.Min().ToString();
                lblEnBuyuk.Text = sayilar.Max().ToString();
                lblToplam.Text = sayilar.Sum().ToString();
                lblOrtalama.Text = ortalama.ToString();
                lblOrtalamayaEnYakin.Text = yakin.ToString();
            }
        }

        private void btnEscape_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
