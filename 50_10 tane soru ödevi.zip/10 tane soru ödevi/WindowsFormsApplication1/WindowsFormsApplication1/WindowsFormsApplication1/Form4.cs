﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //int sayi = txtAnaYazi.Text.IndexOf(txtBul.Text );
            //            MessageBox.Show (txtBul.Text +" yazisinin Sirası : "+ sayi );
            int say = 0;
            foreach (char item in txtAnaYazi.Text)
            {
                say++;
                char bul = Convert.ToChar(txtBul.Text);

                if (item == bul)
                {
                    MessageBox.Show("Karakter No : " + say);
                }
            }

        }
    }
}
