﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        decimal  ortalama;
        int adet;
        private void btnHesapla_Click(object sender, EventArgs e)
        {

            if (txtOrtalama.Text != "0")
            {

                ortalama += int.Parse(txtOrtalama.Text);
                adet++;
                decimal sonuc = ortalama / adet;

                lblOrtalama.Text = sonuc.ToString();
            }
            else
            {
                MessageBox.Show("0 Girdiniz. işlem Bitti");
                ortalama = 0;
                adet = 0;
            }


        }
    }
}
