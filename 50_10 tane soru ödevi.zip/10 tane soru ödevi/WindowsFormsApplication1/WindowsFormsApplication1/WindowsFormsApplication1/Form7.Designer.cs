﻿namespace WindowsFormsApplication1
{
    partial class Form7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtSayi = new System.Windows.Forms.TextBox();
            this.btnKarakok = new System.Windows.Forms.Button();
            this.btnFaktoriyel = new System.Windows.Forms.Button();
            this.lblKarakok = new System.Windows.Forms.Label();
            this.lblFaktoriyel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtSayi
            // 
            this.txtSayi.Location = new System.Drawing.Point(25, 30);
            this.txtSayi.Name = "txtSayi";
            this.txtSayi.Size = new System.Drawing.Size(114, 20);
            this.txtSayi.TabIndex = 0;
            // 
            // btnKarakok
            // 
            this.btnKarakok.Location = new System.Drawing.Point(25, 56);
            this.btnKarakok.Name = "btnKarakok";
            this.btnKarakok.Size = new System.Drawing.Size(114, 43);
            this.btnKarakok.TabIndex = 1;
            this.btnKarakok.Text = "Karekökünü Al";
            this.btnKarakok.UseVisualStyleBackColor = true;
            this.btnKarakok.Click += new System.EventHandler(this.btnKarakok_Click);
            // 
            // btnFaktoriyel
            // 
            this.btnFaktoriyel.Location = new System.Drawing.Point(25, 105);
            this.btnFaktoriyel.Name = "btnFaktoriyel";
            this.btnFaktoriyel.Size = new System.Drawing.Size(114, 37);
            this.btnFaktoriyel.TabIndex = 2;
            this.btnFaktoriyel.Text = "Faktoriyelini Al";
            this.btnFaktoriyel.UseVisualStyleBackColor = true;
            this.btnFaktoriyel.Click += new System.EventHandler(this.btnFaktoriyel_Click);
            // 
            // lblKarakok
            // 
            this.lblKarakok.AutoSize = true;
            this.lblKarakok.Location = new System.Drawing.Point(163, 71);
            this.lblKarakok.Name = "lblKarakok";
            this.lblKarakok.Size = new System.Drawing.Size(13, 13);
            this.lblKarakok.TabIndex = 3;
            this.lblKarakok.Text = "0";
            // 
            // lblFaktoriyel
            // 
            this.lblFaktoriyel.AutoSize = true;
            this.lblFaktoriyel.Location = new System.Drawing.Point(163, 117);
            this.lblFaktoriyel.Name = "lblFaktoriyel";
            this.lblFaktoriyel.Size = new System.Drawing.Size(13, 13);
            this.lblFaktoriyel.TabIndex = 4;
            this.lblFaktoriyel.Text = "0";
            // 
            // Form7
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.lblFaktoriyel);
            this.Controls.Add(this.lblKarakok);
            this.Controls.Add(this.btnFaktoriyel);
            this.Controls.Add(this.btnKarakok);
            this.Controls.Add(this.txtSayi);
            this.Name = "Form7";
            this.Text = "Form7";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtSayi;
        private System.Windows.Forms.Button btnKarakok;
        private System.Windows.Forms.Button btnFaktoriyel;
        private System.Windows.Forms.Label lblKarakok;
        private System.Windows.Forms.Label lblFaktoriyel;
    }
}