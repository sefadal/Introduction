﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnYazdir_Click(object sender, EventArgs e)
        {
            Label lbl;
            int down = 20;
            for (int i = 0; i < 10; i++)
            {
                lbl = new Label();

                lbl.Text = txtYazi.Text;
                lbl.Name = "lbl" + i;
                lbl.AutoSize = true;
                lbl.Location = new Point(250, down);

                down += 20;
                this.Controls.Add(lbl);
            }


        }
    }
}
