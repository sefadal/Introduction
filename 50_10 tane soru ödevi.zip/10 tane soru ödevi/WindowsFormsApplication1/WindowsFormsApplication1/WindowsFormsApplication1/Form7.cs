﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }

        private void btnKarakok_Click(object sender, EventArgs e)
        {
            double sayi = double.Parse(txtSayi.Text);

            lblKarakok.Text = Math.Sqrt(sayi).ToString();
        }

        private void btnFaktoriyel_Click(object sender, EventArgs e)
        {
            int sayi = int.Parse(txtSayi.Text);
            int topla = sayi;

            for (int i = sayi ; i > 1; --i)
            {
                topla += i * (i -1);
            }
            
            
            lblFaktoriyel.Text =  topla.ToString();
        }
    }
}
