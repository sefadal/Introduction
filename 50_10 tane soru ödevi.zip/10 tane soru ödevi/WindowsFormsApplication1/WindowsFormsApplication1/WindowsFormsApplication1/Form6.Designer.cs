﻿namespace WindowsFormsApplication1
{
    partial class Form6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnHesapla = new System.Windows.Forms.Button();
            this.txtKilo = new System.Windows.Forms.TextBox();
            this.txtBoy = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtBoy1 = new System.Windows.Forms.TextBox();
            this.txtKilo1 = new System.Windows.Forms.TextBox();
            this.btnHesap = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.lblKitleIndex = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnHesapla
            // 
            this.btnHesapla.Location = new System.Drawing.Point(12, 75);
            this.btnHesapla.Name = "btnHesapla";
            this.btnHesapla.Size = new System.Drawing.Size(115, 42);
            this.btnHesapla.TabIndex = 0;
            this.btnHesapla.Text = "Kitle İndexini Hesapla";
            this.btnHesapla.UseVisualStyleBackColor = true;
            this.btnHesapla.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtKilo
            // 
            this.txtKilo.Location = new System.Drawing.Point(75, 49);
            this.txtKilo.Name = "txtKilo";
            this.txtKilo.Size = new System.Drawing.Size(52, 20);
            this.txtKilo.TabIndex = 1;
            // 
            // txtBoy
            // 
            this.txtBoy.Location = new System.Drawing.Point(12, 49);
            this.txtBoy.Name = "txtBoy";
            this.txtBoy.Size = new System.Drawing.Size(54, 20);
            this.txtBoy.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(25, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Boy";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(76, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(24, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Kilo";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(235, 33);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(24, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Kilo";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(170, 33);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(25, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Boy";
            // 
            // txtBoy1
            // 
            this.txtBoy1.Location = new System.Drawing.Point(171, 49);
            this.txtBoy1.Name = "txtBoy1";
            this.txtBoy1.Size = new System.Drawing.Size(54, 20);
            this.txtBoy1.TabIndex = 7;
            // 
            // txtKilo1
            // 
            this.txtKilo1.Location = new System.Drawing.Point(234, 49);
            this.txtKilo1.Name = "txtKilo1";
            this.txtKilo1.Size = new System.Drawing.Size(52, 20);
            this.txtKilo1.TabIndex = 6;
            // 
            // btnHesap
            // 
            this.btnHesap.Location = new System.Drawing.Point(171, 75);
            this.btnHesap.Name = "btnHesap";
            this.btnHesap.Size = new System.Drawing.Size(115, 42);
            this.btnHesap.TabIndex = 5;
            this.btnHesap.Text = "Kiloyu Hesapla";
            this.btnHesap.UseVisualStyleBackColor = true;
            this.btnHesap.Click += new System.EventHandler(this.btnHesap_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 129);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Vucut Kitle İndexi";
            // 
            // lblKitleIndex
            // 
            this.lblKitleIndex.AutoSize = true;
            this.lblKitleIndex.Location = new System.Drawing.Point(17, 146);
            this.lblKitleIndex.Name = "lblKitleIndex";
            this.lblKitleIndex.Size = new System.Drawing.Size(13, 13);
            this.lblKitleIndex.TabIndex = 11;
            this.lblKitleIndex.Text = "0";
            // 
            // Form6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(315, 265);
            this.Controls.Add(this.lblKitleIndex);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtBoy1);
            this.Controls.Add(this.txtKilo1);
            this.Controls.Add(this.btnHesap);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtBoy);
            this.Controls.Add(this.txtKilo);
            this.Controls.Add(this.btnHesapla);
            this.Name = "Form6";
            this.Text = "Form6";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnHesapla;
        private System.Windows.Forms.TextBox txtKilo;
        private System.Windows.Forms.TextBox txtBoy;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtBoy1;
        private System.Windows.Forms.TextBox txtKilo1;
        private System.Windows.Forms.Button btnHesap;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblKitleIndex;
    }
}