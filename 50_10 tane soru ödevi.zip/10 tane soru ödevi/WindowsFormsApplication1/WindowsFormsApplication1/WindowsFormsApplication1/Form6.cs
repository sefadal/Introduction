﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            //  Boyun karesi alınıp  kiloya  bölünür 
            //  kare almak için sayıyı kendine çarpmak lazımdır.

            decimal boy = decimal.Parse(txtBoy.Text) / 100;
            decimal kilo = decimal.Parse(txtKilo.Text);
            decimal boyKare = boy * boy;
            decimal kitleIndex = kilo / boyKare;
            string durum = "";

            if (kitleIndex < 18)
                durum = "Çok Çok Zayıfsın Problem Var";
            else if (kitleIndex > 18 && kitleIndex < 25)
                durum = "İdeal Kilodasın. Tebrikler.";
            else if (kitleIndex > 25 && kitleIndex < 30)
                durum = "Fazla Kilolusunuz.";
            else if (kitleIndex > 30 && kitleIndex < 40)
                durum = "Siz Obezite Hastası Olmuşsunuz.";
            else if (kitleIndex > 40)
                durum = "Çok Fazla Kilonuz Var. Acilen Zayıflamaya Çalışın.";

            lblKitleIndex.Text = kitleIndex.ToString();
            MessageBox.Show(durum);
        }



        private void btnHesap_Click(object sender, EventArgs e)
        {

            decimal kilo = decimal.Parse(txtKilo1.Text);
            decimal boy = decimal.Parse(txtBoy1.Text) - 100;
            string durum = "";

            if (kilo == boy)
                durum = "İdeal Kilodasınız";
            else if (boy < kilo)
                durum = "Kilo vermelisiniz. Vermeniz gereken kilo : " + (kilo - boy);
            else durum = "Zayıfsınız almanız gereken kilo : " + (boy - kilo);

            MessageBox.Show(durum);
        }
    }
}
